#!/usr/bin/env bash
set -e
cd -- "$(dirname -- "$0")"
if ! command -v python3 >/dev/null 2>&1; then
  echo 'Python 3.10 or later is required. Install Python, then run this script again.'
  exit 1
fi
exec python3 app.py "$@"
