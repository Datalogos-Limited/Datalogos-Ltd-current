#!/usr/bin/env python3
"""Offline integrity check. Optional key verifies the local issuer, not revocation."""
import argparse
import json
from pathlib import Path
from datalogos.datafolio import check

parser = argparse.ArgumentParser(description="Verify a portable Datafolio JSON bundle")
parser.add_argument("bundle", type=Path)
parser.add_argument("--issuer-key", type=Path, help="Optional private issuer key of the originating installation. Keep this key private.")
args = parser.parse_args()
try:
    bundle = json.loads(args.bundle.read_text(encoding="utf-8"))
    result = check(bundle, args.issuer_key.read_bytes() if args.issuer_key else None)
    result["permission_active"] = "Unknown offline: check the originating POC for expiry, revocation and policy status."
    print(json.dumps(result, indent=2))
    raise SystemExit(0 if result["integrity_valid"] and result["issuer_valid"] is not False else 1)
except (OSError, ValueError) as exc:
    parser.exit(2, f"Cannot verify bundle: {exc}\n")
