#!/usr/bin/env python3
"""Local-only HTTP adapter; uses Python's standard library exclusively."""
import argparse
import json
import mimetypes
import secrets
import threading
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit, parse_qs
from datalogos import __version__
from datalogos.common import Problem, choice, canonical
from datalogos.service import Service, PERSONAS

ROOT = Path(__file__).resolve().parent


def make_server(service, port=8765):
    sessions, lock = {}, threading.Lock()

    class Handler(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"

        def log_message(self, fmt, *args):
            # Do not print request contents or data. Only local paths and status.
            pass

        def send(self, status, content, mime="application/json; charset=utf-8", extra=None):
            body = canonical(content).encode() if mime.startswith("application/json") else content
            self.send_response(status)
            self.send_header("Content-Type", mime)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Referrer-Policy", "no-referrer")
            self.send_header("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
            if extra:
                for key, value in extra.items():
                    self.send_header(key, value)
            self.end_headers()
            self.wfile.write(body)

        def guard(self):
            port = self.server.server_address[1]
            allowed = {f"127.0.0.1:{port}", f"localhost:{port}"}
            host = self.headers.get("Host", "")
            if host not in allowed:
                raise Problem("Only this local host is permitted.", 403)
            origin = self.headers.get("Origin")
            if origin and origin != f"http://{host}":
                raise Problem("Cross-origin requests are not permitted.", 403)
            if self.headers.get("Sec-Fetch-Site") == "cross-site":
                raise Problem("Cross-site requests are not permitted.", 403)

        def session(self):
            try:
                cookie = SimpleCookie(self.headers.get("Cookie", ""))
                token = cookie.get("datalogos_session")
                identifier = token.value if token else None
            except Exception:
                identifier = None
            with lock:
                session = sessions.get(identifier)
                if not session:
                    raise Problem("Refresh the page to initialise a local session.", 401)
                return dict(session)

        def do_GET(self):
            try:
                self.guard()
                parsed = urlsplit(self.path)
                path = parsed.path
                if path == "/api/health":
                    self.send(200, {"status": "ok", "version": __version__, "mode": "local-poc"})
                elif path == "/api/session":
                    try:
                        session = self.session()
                        self.send(200, session)
                    except Problem:
                        token = secrets.token_urlsafe(32)
                        session = {"csrf": secrets.token_urlsafe(32), "persona": "operator", "mode": "demo-personas"}
                        with lock:
                            if len(sessions) >= 128:
                                sessions.pop(next(iter(sessions)))
                            sessions[token] = session
                        self.send(200, session, extra={"Set-Cookie": f"datalogos_session={token}; HttpOnly; SameSite=Strict; Path=/"})
                elif path == "/api/state":
                    self.session()
                    self.send(200, service.state())
                elif path.startswith("/api/wallets/") and path.endswith("/export"):
                    self.session()
                    parts = path.strip("/").split("/")
                    if len(parts) != 4:
                        raise Problem("Route not found.", 404)
                    grant_id = parse_qs(parsed.query).get("grant_id", [None])[0]
                    self.send(200, service.export(parts[2], grant_id), extra={"Content-Disposition": 'attachment; filename="datafolio-evidence.json"'})
                elif path in {"/samples/clean.csv", "/samples/poor-quality.csv", "/samples/missing-consent.csv", "/samples/injection.csv", "/samples/restricted.csv"}:
                    file = ROOT / path[1:]
                    self.send(200, file.read_bytes(), "text/csv; charset=utf-8")
                elif path in {"/", "/app.js", "/style.css", "/favicon.svg"}:
                    file = ROOT / "static" / ("index.html" if path == "/" else path[1:])
                    self.send(200, file.read_bytes(), mimetypes.guess_type(file.name)[0] or "application/octet-stream")
                else:
                    raise Problem("Route not found.", 404)
            except Problem as exc:
                self.send(exc.status, {"error": str(exc)})
            except (BrokenPipeError, ConnectionResetError):
                pass
            except Exception:
                self.send(500, {"error": "Local operation failed. Check available disk space and restart."})

        def do_POST(self):
            try:
                self.guard()
                if self.headers.get("Transfer-Encoding"):
                    raise Problem("Chunked requests are not supported.")
                if self.headers.get("Content-Type", "").split(";")[0] != "application/json":
                    raise Problem("Use application/json.", 415)
                try:
                    size = int(self.headers.get("Content-Length", "0"))
                except ValueError:
                    raise Problem("Invalid content length.")
                if not 1 <= size <= 2_000_000:
                    raise Problem("Request must be 1 byte–2 MB.", 413)
                session = self.session()
                if not secrets.compare_digest(self.headers.get("X-CSRF-Token", ""), session["csrf"]):
                    raise Problem("Request token is missing or invalid.", 403)
                try:
                    body = json.loads(self.rfile.read(size), parse_constant=lambda _: (_ for _ in ()).throw(ValueError()))
                except (ValueError, UnicodeError):
                    raise Problem("Request is not valid JSON.")
                if not isinstance(body, dict):
                    raise Problem("Request body must be a JSON object.")
                path = urlsplit(self.path).path
                actor = session["persona"]
                if path == "/api/persona":
                    persona = choice(body.get("persona"), "Persona", list(PERSONAS))
                    cookie = SimpleCookie(self.headers.get("Cookie", ""))
                    with lock:
                        sessions[cookie["datalogos_session"].value]["persona"] = persona
                    result = {"persona": persona}
                elif path == "/api/datasets":
                    result = service.dataset(body, actor)
                elif path == "/api/evaluate":
                    result = service.evaluate(body, actor)
                elif path == "/api/policy":
                    result = service.policy(body, actor)
                elif path == "/api/verify":
                    result = service.verify(body.get("bundle"))
                else:
                    parts = path.strip("/").split("/")
                    if len(parts) != 4 or parts[0] != "api":
                        raise Problem("Route not found.", 404)
                    _, group, identifier, action = parts
                    if group == "runs" and action == "approve":
                        result = service.approval(identifier, body, actor)
                    elif group == "runs" and action == "execute":
                        result = service.execute(identifier, actor)
                    elif group == "wallets" and action == "grant":
                        result = service.grant(identifier, body, actor)
                    elif group == "wallets" and action == "revoke":
                        result = service.revoke(identifier, body, actor)
                    else:
                        raise Problem("Route not found.", 404)
                self.send(200, result)
            except Problem as exc:
                self.close_connection = True
                self.send(exc.status, {"error": str(exc)})
            except (BrokenPipeError, ConnectionResetError):
                pass
            except Exception:
                self.close_connection = True
                self.send(500, {"error": "Local operation failed. Check available disk space and restart."})

    server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    server.daemon_threads = True
    return server


def main():
    parser = argparse.ArgumentParser(description="Datalogos local POC")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--data-dir", type=Path, default=ROOT / "runtime")
    args = parser.parse_args()
    if not 1024 <= args.port <= 65535:
        parser.error("Use a port between 1024 and 65535.")
    service = Service(args.data_dir)
    try:
        server = make_server(service, args.port)
    except OSError as exc:
        parser.exit(1, f"Cannot start on port {args.port}: {exc}. Try --port 8766.\n")
    print(f"Datalogos POC {__version__}: http://127.0.0.1:{args.port}", flush=True)
    print("Offline demonstration with selectable personas. Press Ctrl+C to stop.", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped. Local records retained.")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
