// Optional frontend event smoke test with a deliberately limited DOM stub.
// Requires Node 18+ and a running disposable POC with default external policy.
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const path=require('node:path');
const html=fs.readFileSync(path.join(__dirname,'..','static','index.html'),'utf8');
const base=process.env.POC_URL || 'http://127.0.0.1:8765';
class Element{
 constructor(id=''){this.id=id;this.value='';this.checked=false;this.disabled=false;this.hidden=false;this.dataset={};this.handlers={};this.attrs={};this.classList={toggle(){}};this.textContent='';this.files=[];}
 addEventListener(type,fn){this.handlers[type]=fn;}
 set innerHTML(value){this.content=value;if(this.id==='dataset-select'){const options=[...value.matchAll(/<option value="([^"]*)"([^>]*)>/g)];this.value=(options.find(m=>m[2].includes('selected'))||options[0]||['',''])[1];}}
 get innerHTML(){return this.content||'';}
 setAttribute(k,v){this.attrs[k]=v;}removeAttribute(k){delete this.attrs[k];}hasAttribute(k){return k in this.attrs;}
 querySelector(selector){if(this.id==='policy-form'&&selector==='button')return policyButton;throw new Error('Unhandled element query '+selector);}
 closest(selector){if(selector==='button')return this;if(selector==='#policy-form')return this===policyButton?elements.get('policy-form'):null;return null;}
 click(){}
}
const elements=new Map([...html.matchAll(/id="([^"]+)"/g)].map(m=>[m[1],new Element(m[1])]));
const policyButton=new Element();
const tabs=['workflow','verity','counterpoise','datafolio','audit','guide'].map(name=>{const b=new Element();b.dataset.tab=name;return b;});
const document={body:new Element('body'),handlers:{},getElementById(id){if(!elements.has(id)){if(!/^(reason|recipient|ttl)-[0-9a-f]+$/.test(id))throw new Error('Unknown DOM id '+id);elements.set(id,new Element(id));}return elements.get(id);},addEventListener(t,fn){this.handlers[t]=fn;},querySelectorAll(selector){if(selector==='.page')return tabs.map(b=>elements.get(b.dataset.tab));if(selector==='[data-tab]')return tabs;if(selector.startsWith('[data-field-wallet='))return ['region','total'].map(value=>({value}));throw new Error('Unhandled document query '+selector);},querySelector(selector){return{textContent:selector};},createElement(){return new Element();}};
let cookie='';const nativeFetch=global.fetch;
async function fetchLocal(path,opts={}){const response=await nativeFetch(base+path,{...opts,headers:{...opts.headers,...(cookie?{Cookie:cookie}:{})}});const setCookie=response.headers.get('set-cookie');if(setCookie)cookie=setCookie.split(';')[0];return response;}
const context=vm.createContext({document,fetch:fetchLocal,console,URL,Blob,Date,JSON,Error,String,Number,setTimeout});
vm.runInContext(fs.readFileSync(path.join(__dirname,'..','static','app.js'),'utf8'),context);
async function idle(){for(let i=0;i<400;i++){if(!vm.runInContext('busy',context))return;await new Promise(r=>setTimeout(r,10));}throw new Error('UI request did not complete');}
async function click(id,dataset={}){const b=id?elements.get(id):new Element();b.dataset=dataset;document.handlers.click({target:b});await idle();if(elements.get('notice').classList.error)throw new Error(elements.get('notice').textContent);}
async function persona(value){elements.get('persona').value=value;elements.get('persona').handlers.change();await idle();}
(async()=>{
 await idle();assert.ok(elements.get('scenarios').innerHTML.includes('Clean sales'));
 await click(null,{scenario:'clean'});await click('evaluate');assert.match(elements.get('current-run').innerHTML,/ALLOW/);
 let id=vm.runInContext('currentRun',context);await click(null,{execute:id});assert.match(elements.get('current-run').innerHTML,/1550.25/);
 for(const scenario of ['quality','privacy','injection','restricted']){await click(null,{scenario});await click('evaluate');assert.match(elements.get('current-run').innerHTML,/BLOCK/);assert.ok(!elements.get('current-run').innerHTML.includes('data-execute'));}
 await click(null,{scenario:'review'});await click('evaluate');id=vm.runInContext('currentRun',context);assert.match(elements.get('current-run').innerHTML,/REVIEW/);
 await persona('reviewer');document.getElementById('reason-'+id).value='Reviewed aggregate use with human responsibility.';await click(null,{approve:id});await persona('operator');await click(null,{execute:id});assert.match(elements.get('current-run').innerHTML,/EXECUTED/);
 await click(null,{scenario:'external'});await click('evaluate');id=vm.runInContext('currentRun',context);await click(null,{execute:id});
 const wallet=vm.runInContext('state.wallets[0]',context);document.getElementById('recipient-'+wallet.id).value='investor@example.test';document.getElementById('ttl-'+wallet.id).value='15';
 await click(null,{grant:wallet.id});const grantId=vm.runInContext('state.wallets[0].grants[0].id',context);
 await click(null,{grantExport:wallet.id,grantId});await click('verify-bundle');assert.match(elements.get('verification').innerHTML,/Live permission:<\/strong> Active/);
 await click(null,{grantRevoke:wallet.id,grantId});await click('verify-bundle');assert.match(elements.get('verification').innerHTML,/Live permission:<\/strong> Inactive/);
 const modified=JSON.parse(elements.get('bundle-json').value);modified.payload.records[0].total='0.00';elements.get('bundle-json').value=JSON.stringify(modified);await click('verify-bundle');assert.match(elements.get('verification').innerHTML,/Record integrity:<\/strong> Failed/);
 await persona('admin');elements.get('minimum-quality').value='96';
 document.handlers.click({target:policyButton});elements.get('policy-form').handlers.submit({preventDefault(){}});await idle();assert.equal(vm.runInContext('state.policy.minimum_quality',context),96);
 assert.match(elements.get('notice').textContent,/New policy version/);
 console.log('PASS: frontend rendering and event handlers against real local API: scenario loading, allow/execution, four blocks, human review, persona changes, scoped export, revocation, tamper verification, policy form submission. DOM stub only; visual browser rendering not tested.');
})().catch(e=>{console.error(e);process.exitCode=1;});
