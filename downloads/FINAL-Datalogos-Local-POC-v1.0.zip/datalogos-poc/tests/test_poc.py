import copy
import json
import tempfile
import threading
import unittest
import urllib.request
import urllib.error
import http.cookiejar
from pathlib import Path
from datetime import datetime, timezone, timedelta
from datalogos.common import Problem, digest
from datalogos.service import Service
from datalogos import verity, datafolio
from app import make_server

ROOT = Path(__file__).resolve().parents[1]


class WorkflowTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.service = Service(Path(self.temp.name))

    def tearDown(self):
        self.temp.cleanup()

    def dataset(self, sample="clean", classification="internal", csv=None):
        return self.service.dataset({"name": sample, "source": "Synthetic test fixture", "owner": "Test team",
             "purpose": "sales-analysis", "classification": classification,
             "csv": csv if csv is not None else (ROOT / "samples" / (sample + ".csv")).read_text()}, "operator")

    def request(self, dataset, destination="internal", high_impact=False, purpose="sales-analysis"):
        return self.service.evaluate({"dataset_id": dataset["id"], "destination": destination,
             "high_impact": high_impact, "purpose": purpose}, "operator")

    def wallet(self, external=True):
        run = self.request(self.dataset(), "external" if external else "internal")
        return self.service.execute(run["id"], "operator")

    def grant(self, wallet_id):
        return self.service.grant(wallet_id, {"recipient": "investor@example.test", "minutes": 15, "fields": ["region", "total"]}, "operator")

    def test_clean_full_workflow_and_persistence(self):
        dataset = self.dataset()
        self.assertEqual(dataset["assurance"]["quality_score"], 100)
        run = self.request(dataset)
        self.assertEqual(run["state"], "allow")
        executed = self.service.execute(run["id"], "operator")
        totals = {r["region"]: r["total"] for r in executed["output"]}
        self.assertEqual(totals, {"North": "1550.25", "South": "1000.00", "East": "620.00", "West": "410.75"})
        bundle = self.service.export(executed["wallet_id"])
        self.assertTrue(self.service.verify(bundle)["issuer_valid"])
        self.assertTrue(self.service.verify(bundle)["permission_active"])
        restored = Service(Path(self.temp.name))
        self.assertTrue(restored.verify(bundle)["issuer_valid"])
        self.assertEqual(len(restored.state()["runs"]), 1)

    def test_quality_block_cannot_execute(self):
        run = self.request(self.dataset("poor-quality"))
        self.assertEqual(run["state"], "block")
        with self.assertRaises(Problem): self.service.execute(run["id"], "operator")
        self.assertEqual(len(self.service.state()["wallets"]), 0)

    def test_privacy_is_destination_specific(self):
        dataset = self.dataset("missing-consent")
        self.assertEqual(self.request(dataset)["state"], "allow")
        external = self.request(dataset, "external")
        self.assertEqual(external["state"], "block")
        self.assertEqual(external["decision"]["engines"][1]["status"], "block")

    def test_injection_blocks(self):
        self.assertEqual(self.request(self.dataset("injection"))["state"], "block")

    def test_restricted_external_blocks(self):
        self.assertEqual(self.request(self.dataset("restricted", "restricted"), "external")["state"], "block")

    def test_purpose_mismatch_blocks(self):
        self.assertEqual(self.request(self.dataset(), purpose="recruitment")["state"], "block")

    def test_human_review_execution(self):
        run = self.request(self.dataset(), high_impact=True)
        self.assertEqual(run["state"], "review")
        with self.assertRaises(Problem): self.service.execute(run["id"], "operator")
        with self.assertRaises(Problem): self.service.approval(run["id"], {"decision": "approve", "reason": "I approve"}, "operator")
        self.service.approval(run["id"], {"decision": "approve", "reason": "Aggregate totals reviewed; retain human responsibility."}, "reviewer")
        self.assertEqual(self.service.execute(run["id"], "operator")["state"], "executed")

    def test_reject_prevents_execution(self):
        run = self.request(self.dataset(), high_impact=True)
        self.service.approval(run["id"], {"decision": "reject", "reason": "Unclear intended use."}, "reviewer")
        with self.assertRaises(Problem): self.service.execute(run["id"], "operator")

    def test_block_cannot_be_approved(self):
        run = self.request(self.dataset("poor-quality"))
        with self.assertRaises(Problem): self.service.approval(run["id"], {"decision": "approve", "reason": "Attempted override."}, "reviewer")

    def test_execution_cannot_replay(self):
        run = self.wallet()
        with self.assertRaises(Problem): self.service.execute(run["id"], "operator")
        self.assertEqual(len(self.service.state()["wallets"]), 1)

    def test_stale_policy_stops_execution(self):
        run = self.request(self.dataset())
        policy = self.service.state()["policy"]
        self.service.policy(policy, "admin")
        with self.assertRaises(Problem): self.service.execute(run["id"], "operator")

    def test_stale_policy_stops_sharing_and_invalidates_permission(self):
        run = self.wallet()
        grant = self.grant(run["wallet_id"])
        bundle = self.service.export(run["wallet_id"], grant["id"])
        self.service.policy(self.service.state()["policy"], "admin")
        with self.assertRaises(Problem): self.service.export(run["wallet_id"], grant["id"])
        with self.assertRaises(Problem): self.grant(run["wallet_id"])
        self.assertFalse(self.service.verify(bundle)["permission_active"])

    def test_changed_source_stops_execution(self):
        dataset = self.dataset()
        run = self.request(dataset)
        with self.service.store.transaction() as db:
            saved = self.service.store.get(db, "datasets", dataset["id"])
            saved["rows"][0]["amount"] = "999.00"
            self.service.store.put(db, "datasets", dataset["id"], saved)
        with self.assertRaises(Problem): self.service.execute(run["id"], "operator")

    def test_changed_assurance_stops_execution(self):
        dataset = self.dataset()
        run = self.request(dataset)
        with self.service.store.transaction() as db:
            saved = self.service.store.get(db, "datasets", dataset["id"])
            saved["assurance"]["quality_score"] = 99.0
            self.service.store.put(db, "datasets", dataset["id"], saved)
        with self.assertRaises(Problem): self.service.execute(run["id"], "operator")

    def test_scope_excludes_personal_fields(self):
        run = self.wallet()
        grant = self.grant(run["wallet_id"])
        bundle = self.service.export(run["wallet_id"], grant["id"])
        self.assertEqual(set(bundle["payload"]["records"][0]), {"region", "total"})
        self.assertNotIn("alex@example.test", json.dumps(bundle))
        self.assertTrue(self.service.verify(bundle)["permission_active"])

    def test_internal_wallet_cannot_grant_external_share(self):
        run = self.wallet(False)
        with self.assertRaises(Problem): self.grant(run["wallet_id"])

    def test_revocation_preserves_integrity_but_removes_authority(self):
        run = self.wallet()
        grant = self.grant(run["wallet_id"])
        bundle = self.service.export(run["wallet_id"], grant["id"])
        self.service.revoke(run["wallet_id"], {"grant_id": grant["id"]}, "operator")
        check = self.service.verify(bundle)
        self.assertTrue(check["integrity_valid"])
        self.assertTrue(check["issuer_valid"])
        self.assertFalse(check["permission_active"])
        with self.assertRaises(Problem): self.service.export(run["wallet_id"], grant["id"])

    def test_wallet_revocation(self):
        run = self.wallet()
        bundle = self.service.export(run["wallet_id"])
        self.service.revoke(run["wallet_id"], {}, "operator")
        with self.assertRaises(Problem): self.service.export(run["wallet_id"])
        with self.assertRaises(Problem): self.grant(run["wallet_id"])
        self.assertFalse(self.service.verify(bundle)["permission_active"])

    def test_expiry_prevents_access(self):
        run = self.wallet()
        grant = self.grant(run["wallet_id"])
        bundle = self.service.export(run["wallet_id"], grant["id"])
        with self.service.store.transaction() as db:
            wallet = self.service.store.get(db, "wallets", run["wallet_id"])
            wallet["grants"][0]["expires_at"] = (datetime.now(timezone.utc) - timedelta(minutes=1)).isoformat()
            self.service.store.put(db, "wallets", run["wallet_id"], wallet)
        with self.assertRaises(Problem): self.service.export(run["wallet_id"], grant["id"])
        self.assertFalse(self.service.verify(bundle)["permission_active"])

    def test_altered_bundle_and_rehashed_bundle_fail_issuer(self):
        run = self.wallet()
        bundle = copy.deepcopy(self.service.export(run["wallet_id"]))
        bundle["payload"]["records"][0]["total"] = "0.00"
        self.assertFalse(self.service.verify(bundle)["integrity_valid"])
        bundle["digest"] = digest(bundle["payload"])
        check = self.service.verify(bundle)
        self.assertTrue(check["integrity_valid"])
        self.assertFalse(check["issuer_valid"])

    def test_foreign_installation_cannot_authenticate_bundle(self):
        bundle = self.service.export(self.wallet()["wallet_id"])
        with tempfile.TemporaryDirectory() as other:
            self.assertFalse(Service(Path(other)).verify(bundle)["issuer_valid"])
        self.assertIsNone(datafolio.check(bundle)["issuer_valid"])

    def test_browser_numeric_roundtrip_preserves_signature(self):
        bundle = copy.deepcopy(self.service.export(self.wallet()["wallet_id"]))
        bundle["payload"]["assurance"]["quality_score"] = 100
        self.assertTrue(self.service.verify(bundle)["issuer_valid"])

    def test_audit_append_only_and_valid(self):
        self.wallet()
        self.assertTrue(self.service.state()["audit"]["valid"])
        with self.assertRaises(Exception):
            with self.service.store.transaction() as db: db.execute("DELETE FROM events")
        self.assertTrue(self.service.state()["audit"]["valid"])

    def test_invalid_inputs_fail_closed(self):
        with self.assertRaises(Problem): verity.parse_csv("a,b\n1,2\n")
        with self.assertRaises(Problem): verity.parse_csv("record_id,region,amount,consent\nx,North,1,true,extra\n")
        with self.assertRaises(Problem): self.service.evaluate({"high_impact": "false"}, "operator")
        with self.assertRaises(Problem): self.service.policy(self.service.state()["policy"], "operator")
        run = self.wallet()
        with self.assertRaises(Problem): self.service.grant(run["wallet_id"], {"recipient": "x@example.test", "minutes": 1, "fields": ["email"]}, "operator")
        self.assertIsNone(verity.amount("NaN"))
        self.assertIsNone(verity.amount("Infinity"))
        self.assertIsNone(verity.amount("0.001"))


class HTTPTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory()
        cls.server = make_server(Service(Path(cls.temp.name)), 0)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.url = "http://127.0.0.1:" + str(cls.server.server_address[1])

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join()
        cls.temp.cleanup()

    def setUp(self):
        self.opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
        self.session = json.load(self.opener.open(self.url + "/api/session"))

    def post(self, path, body, headers=None):
        h = {"Content-Type": "application/json", "X-CSRF-Token": self.session["csrf"]}
        h.update(headers or {})
        return self.opener.open(urllib.request.Request(self.url + path, json.dumps(body).encode(), h))

    def test_health_static_and_no_sensitive_paths(self):
        self.assertEqual(json.load(self.opener.open(self.url + "/api/health"))["status"], "ok")
        self.assertIn(b"Make governance work", self.opener.open(self.url).read())
        for path in ["/runtime/issuer.key", "/../app.py", "/samples/../app.py"]:
            with self.assertRaises(urllib.error.HTTPError) as ctx: self.opener.open(self.url + path)
            self.assertEqual(ctx.exception.code, 404)

    def test_csrf_and_cross_origin_rejected(self):
        with self.assertRaises(urllib.error.HTTPError) as ctx: self.post("/api/persona", {"persona":"admin"}, {"X-CSRF-Token":"invalid"})
        self.assertEqual(ctx.exception.code, 403)
        with self.assertRaises(urllib.error.HTTPError) as ctx: self.post("/api/persona", {"persona":"admin"}, {"Origin":"https://malicious.example"})
        self.assertEqual(ctx.exception.code, 403)

    def test_bad_host_rejected(self):
        with self.assertRaises(urllib.error.HTTPError) as ctx: self.opener.open(urllib.request.Request(self.url + "/api/health", headers={"Host":"malicious.example"}))
        self.assertEqual(ctx.exception.code, 403)

    def test_api_workflow(self):
        d = json.load(self.post("/api/datasets", {"csv":(ROOT/"samples/clean.csv").read_text(), "name":"HTTP fixture", "source":"Fixture", "owner":"Tests", "purpose":"sales-analysis", "classification":"internal"}))
        r = json.load(self.post("/api/evaluate", {"dataset_id":d["id"], "destination":"internal", "purpose":"sales-analysis", "high_impact":False}))
        executed = json.load(self.post(f"/api/runs/{r['id']}/execute", {}))
        bundle = json.load(self.opener.open(self.url + f"/api/wallets/{executed['wallet_id']}/export"))
        self.assertTrue(json.load(self.post("/api/verify", {"bundle":bundle}))["issuer_valid"])


if __name__ == "__main__":
    unittest.main()
