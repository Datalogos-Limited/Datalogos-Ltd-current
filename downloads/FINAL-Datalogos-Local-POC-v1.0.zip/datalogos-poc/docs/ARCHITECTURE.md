# Implementation architecture

Version 1.0.0 · Local POC · Datalogos Limited · 3 October 2026

## The integrated chain

```mermaid
flowchart TB
  UI["Local browser interface"] --> API["Python API and session boundary"]
  API --> V["Verity: inspect and fingerprint CSV"]
  V --> O["Counterpoise: resolve request context"]
  subgraph Engines["Policy engines"]
    G["Governance"]
    P["Privacy"]
    E["Ethics"]
    S["Security"]
  end
  O --> G
  O --> P
  O --> E
  O --> S
  G --> PDP["Decision authority"]
  P --> PDP
  E --> PDP
  S --> PDP
  PDP -->|"Block"| Stop["No action"]
  PDP -->|"Review"| H["Human review and rationale"]
  H -->|"Approved"| PEP["Execution enforcement"]
  PDP -->|"Allow"| PEP
  PEP --> A["Regional aggregate report"]
  A --> D["Datafolio: records, provenance and proof"]
  D --> W["Selected-field grants and live verification"]
  V --> DB["SQLite records and hash-chained audit"]
  PDP --> DB
  H --> DB
  D --> DB
```

All components run in one Python process. The browser is a thin client: it does not decide permission or calculate the executed report. JSON API responses come from stored and evaluated backend records. The modules are separately named and testable, rather than separate deployable services in this release.

## Source map

| File | Responsibility |
|---|---|
| `app.py` | Loopback HTTP adapter, static allowlist, session cookies, persona switching, origin/host/CSRF guards, bounded JSON input |
| `datalogos/verity.py` | CSV shape validation, deterministic row checks, personal-data/injection heuristics, canonical dataset hash, decimal aggregation |
| `datalogos/counterpoise.py` | Four engine outcomes, block-first precedence, review escalation and policy version evidence |
| `datalogos/service.py` | Workflow orchestration, state transitions, review, execution, wallet issuance, sharing and revocation |
| `datalogos/datafolio.py` | Canonical payload digest and per-installation HMAC seal; digest and issuer verification |
| `datalogos/store.py` | SQLite schema, atomic transactions, event chain, no-update/no-delete audit triggers |
| `static/index.html` | Six UI views and accessible labelled controls |
| `static/app.js` | Scenario loading, API client, escaped rendering and download interactions |
| `static/style.css` | Datalogos palette, local typography and responsive layout |
| `samples/*.csv` | Synthetic success and failure fixtures |
| `verify_bundle.py` | Portable offline digest and optional local issuer check |
| `tests/test_poc.py` | Backend and real local HTTP regression tests |

## Decision semantics

The POC uses **block → review → allow** precedence. Any engine block prevents action even when another engine requests review. There is no hard-block override.

| Engine | Controls |
|---|---|
| Governance | Approved purpose, matching dataset purpose, minimum quality, every row suitable for aggregation |
| Privacy | External sharing enabled; recorded consent present for personal records when external consent is required |
| Ethics | Consequential-use flag produces human review |
| Security | Known instruction-pattern detection; restricted classification prevents external sharing |

Execution checks are performed inside the same SQLite write transaction as recording the result. The enforcement point requires:

1. An Analyst or Policy steward persona.
2. A run in `allow` or `approved` state.
3. The same canonical input hash used for evaluation.
4. Recomputed Verity checks matching stored assurance.
5. The current policy version and engine outcome matching the original decision.
6. A recorded approval if review was required.

Only then does the deterministic action run and issue a Datafolio wallet. Replaying an executed request is rejected. A policy save invalidates pending execution and later sharing using earlier authority.

## State model

```mermaid
stateDiagram-v2
  [*] --> Evaluated
  Evaluated --> Blocked: engine denies
  Evaluated --> Review: human oversight required
  Evaluated --> Allowed: controls pass
  Review --> Approved: distinct reviewer and rationale
  Review --> Rejected: reviewer rejects
  Allowed --> Executed: enforcement checks pass
  Approved --> Executed: enforcement checks pass
  Blocked --> [*]
  Rejected --> [*]
  Executed --> [*]
```

Policy changes do not erase the historic decision. They prevent execution or sharing until a new request obtains fresh authority.

## Datafolio evidence

The base payload carries:

- Aggregated regional records, issue time, wallet ID and run ID.
- Declared source, dataset name, owner, import time and dataset SHA-256.
- Transformation description, Verity findings and rule version.
- Four engine outcomes, policy version and human approval if applicable.
- Permitted purpose, internal/external destination and output scope.

The payload uses this POC's canonical JSON convention: keys sorted, compact separators, Unicode preserved, integral floating-point values normalised to integers, and non-finite numbers rejected. This preserves signature verification after the browser round-trips JSON numbers such as `100.0` to `100`. It is not a claim of a complete RFC 8785 implementation. SHA-256 fingerprints that canonical payload. HMAC-SHA-256 signs the format, payload and digest using a generated 32-byte local key. This key is not included in exports.

A scoped export additionally carries the recipient label, selected aggregate fields and expiry. A fresh signed projection includes only those selected fields. Live verification separately checks the current database for revocation, expiry and policy version. The mathematical proof remains valid after revocation; the live permission becomes inactive.

HMAC requires the issuer key to authenticate evidence. A recipient with only the JSON can check the unkeyed digest for accidental changes, but cannot independently establish issuer authenticity. A key holder can produce valid HMAC evidence. A production design should use public-key signatures, protected keys and independently published trust material.

## Audit model

Each event includes an actor persona, timestamp, type, entity, details and previous event hash. The new hash is SHA-256 of canonical `{previous_hash, event}`. Events and the related state mutation are committed in a SQLite transaction. Audit triggers reject ordinary update/delete commands.

Verification checks every stored event from the genesis predecessor (`64` zeroes). The UI lists the latest 200 events, while integrity verification checks the whole chain. This model detects inconsistent changes; it does not prove that an administrator has not replaced the entire chain. A retained head outside the database or an external trust anchor would be needed to detect wholesale history replacement or tail truncation.

## Deployment and security boundary

The implementation binds only to IPv4 loopback. Only `localhost:<port>` and `127.0.0.1:<port>` host headers are accepted. Cross-origin and cross-site requests are rejected. Mutations require a server-minted session cookie, JSON content type and CSRF token. No CORS access is provided. Static files use an explicit route allowlist, and runtime/private-key paths are never served.

The UI renders user-controlled values as escaped text. A content security policy permits local scripts and styles and forbids framing and external connections. Database lookups use parameterised values. Payloads and CSV sizes are bounded.

These controls support safe local demonstration. They do not provide authenticated identity, hostile-machine defence, tenancy, TLS, encryption at rest, resilient hosting or a production API perimeter.
