# Validation record

Datalogos Local POC · v1.0.0 · 3 October 2026

## Completed checks

| Check | Result | Scope |
|---|---|---|
| Python compilation | Passed | Backend modules and HTTP adapter |
| JavaScript syntax (`node --check`) | Passed | Front-end script |
| Built-in Python tests | **28 passed** | Real backend logic, SQLite persistence and local HTTP requests |
| Front-end event smoke test | Passed | Real JavaScript event/rendering functions calling the real local API, with a limited DOM stub |
| Full Chromium browser test | **Not completed** | Browser executable was unavailable; browser download failed in the execution environment |
| macOS / Windows native launch | Not exercised | Launchers included; runtime verified on Linux with Python 3.12 |

No visual screenshot or browser accessibility certification is claimed. The CSS includes responsive layouts, keyboard focus indicators and labelled inputs, but these still need visual and assistive-technology review on a real local browser.

## Python regression coverage

The 28 tests exercise:

- Correct decimal report totals and absence of raw personal fields in exported records.
- Dataset/decision/wallet persistence and stable issuer key across restart.
- Quality, privacy, instruction-pattern, restricted-classification and purpose blocks.
- Review gating, distinct persona, rejection and inability to override a block.
- Replay prevention and stale-policy rejection.
- Changed input or altered stored assurance rejection at execution.
- Scoped grants and prevention of external grants on internal-only wallets.
- Grant/wallet revocation, expiry and current-policy invalidation.
- Changed payload detection, rehashed-payload issuer rejection and foreign-key rejection.
- JavaScript-compatible integral numeric round-trip for signed payloads.
- Valid event-chain verification and audit delete prevention.
- Invalid CSV/numeric input, unsupported fields and persona restrictions.
- Real HTTP workflow, CSRF rejection, cross-origin rejection, host validation, and private-file/static-path rejection.

Run from the extracted project directory:

```bash
python3 -m unittest discover -s tests -v
```

## Optional front-end event test

`tests/frontend-smoke.cjs` uses Node's built-in facilities and a small DOM stub. It does **not** open a browser or test CSS layout. It exercises scenario loading, allow/execution, four blocking scenarios, human review, persona switching, scoped export, verification, revocation, altered proof and policy-form submission against an actual running POC.

Node 18 or later is needed **only for this optional developer test**, not for running the POC. Use a disposable runtime because the test creates records and saves a policy version. Start the server in one terminal:

```bash
python3 app.py --data-dir smoke-runtime
```

In a second terminal, from the same project directory:

```bash
node tests/frontend-smoke.cjs
```

The test expects the default policy with external sharing enabled. `POC_URL` may be set to the URL of another loopback port. A real browser review should still check navigation, native downloads, responsive overflow, file upload, keyboard interaction and the approval/wallet walkthrough before a customer demonstration.

## Corrections made during validation

The policy form's submit event is handled separately from the generic click handler, preventing the workflow busy flag from swallowing the save action. Canonical evidence serialisation normalises integral floating-point values so JavaScript's `100.0` → `100` JSON round-trip preserves issuer verification. Both paths passed the front-end event smoke test after correction.
