# Local HTTP API

Base URL: `http://127.0.0.1:8765`. All responses use JSON except static assets and sample CSVs. These are local demonstration endpoints, not a production integration contract.

## Session and write protection

`GET /api/session` creates or reuses a session. Retain the `datalogos_session` cookie and the returned `csrf` token. Mutating requests require:

```text
Content-Type: application/json
X-CSRF-Token: <returned csrf token>
Cookie: datalogos_session=<returned cookie>
```

`GET /api/health` does not require a session. Other API reads do. Browser clients initialise the session automatically. A different host, origin or cross-site request is rejected. This session protects local requests; it does not authenticate a person.

## Routes

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/health` | Version and readiness |
| GET | `/api/session` | Local session and CSRF token |
| POST | `/api/persona` | Select demo persona: operator, reviewer, admin |
| GET | `/api/state` | Dataset assurance (no raw rows), runs, wallets, policy and last 200 audit events |
| POST | `/api/datasets` | Import CSV and perform Verity inspection |
| POST | `/api/evaluate` | Create a Counterpoise policy decision |
| POST | `/api/runs/{id}/approve` | Approve/reject a pending review with rationale |
| POST | `/api/runs/{id}/execute` | Enforce authority, aggregate and issue wallet |
| POST | `/api/policy` | Save a new policy version as admin persona |
| GET | `/api/wallets/{id}/export` | Download owner evidence while wallet is not revoked |
| POST | `/api/wallets/{id}/grant` | Create a selected-field external grant |
| GET | `/api/wallets/{id}/export?grant_id={grant}` | Download permitted projection after expiry/revocation/current-policy checks |
| POST | `/api/wallets/{id}/revoke` | Revoke a wallet or one grant |
| POST | `/api/verify` | Verify integrity, local issuer and live permission |

Owner evidence download is a local archival export; it is not external sharing authority. Current policy permission can be inactive even though an unrevoked historic owner bundle can still be downloaded.

## Request bodies

Import:

```json
{
  "name": "Synthetic sales",
  "source": "Local synthetic fixture",
  "owner": "Demo team",
  "purpose": "sales-analysis",
  "classification": "internal",
  "csv": "record_id,region,amount,consent\nR001,North,125.50,true\n"
}
```

Evaluate:

```json
{"dataset_id":"<dataset id>","purpose":"sales-analysis","destination":"external","high_impact":false}
```

Review (reviewer persona only):

```json
{"decision":"approve","reason":"Aggregated output reviewed for the stated purpose."}
```

Execute: `{}`. The backend looks up the stored request; client-supplied output or verdicts cannot authorise execution.

Policy (admin persona only):

```json
{"minimum_quality":95,"allow_external":true,"require_external_consent":true,"allowed_purposes":["sales-analysis"]}
```

Create a grant (external wallets only):

```json
{"recipient":"investor@example.test","minutes":15,"fields":["region","total"]}
```

Revoke wallet: `{}`. Revoke one grant: `{"grant_id":"<grant id>"}`.

Verify: `{"bundle": <complete exported JSON object>}`. The result includes `integrity_valid`, `issuer_valid`, `permission_active` and a message. Integrity and issuer are historical proof checks; live permission checks current local state.

## Minimal Python client

This example uses only Python's standard library. Run the POC first, then run from its extracted directory:

```python
import json, urllib.request, http.cookiejar
from pathlib import Path

base = "http://127.0.0.1:8765"
client = urllib.request.build_opener(
    urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
session = json.load(client.open(base + "/api/session"))

def post(path, body):
    request = urllib.request.Request(base + path,
        data=json.dumps(body).encode(),
        headers={"Content-Type": "application/json", "X-CSRF-Token": session["csrf"]})
    return json.load(client.open(request))

dataset = post("/api/datasets", {
    "csv": Path("samples/clean.csv").read_text(), "name": "API demonstration",
    "source": "Bundled synthetic fixture", "owner": "Demo team",
    "purpose": "sales-analysis", "classification": "internal"})
run = post("/api/evaluate", {"dataset_id": dataset["id"], "purpose": "sales-analysis",
    "destination": "external", "high_impact": False})
executed = post(f"/api/runs/{run['id']}/execute", {})
bundle = json.load(client.open(base + f"/api/wallets/{executed['wallet_id']}/export"))
print(post("/api/verify", {"bundle": bundle}))
```

## Error handling

Errors use `{"error":"human-readable explanation"}`. Relevant status codes: 400 invalid input, 401 uninitialised session, 403 persona/origin/token/permission denial, 404 unknown record/route, 409 invalid transition/stale authority, 413 oversized request and 415 incorrect content type. No raw exception trace or SQL error is exposed to the browser.
