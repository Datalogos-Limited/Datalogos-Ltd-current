# Demonstration script

Allow 15–20 minutes. Start with a fresh installation or use the newest records if an earlier demonstration has already been run. All data is synthetic.

## 1. Establish a working result

In **Governed workflow**, select **Clean sales**, then **Evaluate with Counterpoise**. Point out that the four engines are independently shown and the decision is `ALLOW`. Select **Execute permitted action**.

Expected result:

| Region | Total | Record count |
|---|---|---|
| East | 620.00 | 1 |
| North | 1550.25 | 2 |
| South | 1000.00 | 2 |
| West | 410.75 | 1 |

The source includes email addresses; the report excludes them. Open **Datafolio wallets**, expand the evidence, and show the input hash, declared source, four engine outcomes and signed output. Export the JSON.

## 2. Show Verity stopping poor input

Return to **Governed workflow** and load **Poor quality**. Evaluate. The result is `BLOCK`. Open **Verity assurance** and inspect the duplicate identifier, missing identifier, invalid region, invalid consent representation and invalid amounts.

Expected: no execution button for the blocked run and no wallet from this run. The quality score is 53.3%, below the default 95% threshold. Changing only the policy threshold cannot make invalid rows safe to aggregate.

## 3. Show destination-sensitive privacy

Load **Missing consent**. It preselects **External sharing**. Evaluate. The Privacy engine blocks use of personal records without recorded consent. Change to **Internal reporting** and evaluate a new request: the simple demonstration policy allows it.

Explain that this illustrates declared purpose/destination controls, not a claim that consent is the only lawful basis or that internal processing is automatically legally permitted.

## 4. Show a security block

Load **Suspicious instructions** and evaluate. Row quality can be 100% while Security blocks an instruction-like string. Its presence does not execute any instruction. Open the Verity findings to show the configured pattern.

Load **Restricted data** and evaluate for external sharing to demonstrate a separate classification control.

## 5. Show accountable human review

Load **Human review** and evaluate. It produces `REVIEW` and cannot execute yet.

1. Open **Counterpoise controls**.
2. Change the demo persona to **Human reviewer**.
3. Enter a rationale such as: “Regional totals reviewed for the stated purpose. A human retains responsibility for consequential decisions.”
4. Approve.
5. Switch back to **Analyst**.
6. Return to **Governed workflow** and execute the approved request, or use its execution button in decision history.

Expected: the wallet includes the reviewer persona, rationale, approval decision and time. A rejected review cannot execute. A hard block never appears in the review queue.

## 6. Show portable permissions

Load **External sharing**, evaluate and execute. In **Datafolio wallets**, use the newest wallet:

1. Expand **Create a scoped sharing grant**.
2. Enter `investor@example.test`. No email is sent.
3. Keep `region` and `total`; clear `record count`.
4. Set expiry to 15 minutes and create the grant.
5. Export its scoped bundle. The verification field is filled with that JSON.
6. Select **Verify integrity and permission**.

Expected: integrity valid, local issuer valid, live permission active. The exported records contain only the selected fields.

Now revoke the grant and verify the same JSON again. Integrity and issuer remain valid, but live permission becomes inactive. Further scoped exports are rejected. Revoking the entire wallet also prevents future owner exports and new grants through this app.

## 7. Demonstrate altered evidence

In the verification JSON field, change one `total` value. Verify again.

Expected: integrity and issuer fail. If an attacker recomputes the unkeyed digest, the local HMAC issuer check still fails. Explain that the offline verifier without a key checks only digest consistency, not authenticity or live permission.

## 8. Demonstrate a policy change

Create an allowed request without executing it. Switch to **Policy steward**, open **Counterpoise controls**, disable external sharing and save a new version. Switch to **Analyst** and attempt to execute the older request.

Expected: enforcement rejects the stale policy authority even if the original decision was allowed. Re-evaluate to obtain a decision against the new version. Previously issued grants also lose live authority after any policy-version change.

## 9. Close with the evidence trail

Open **Evidence trail** and select **Recheck**. Show a Verity inspection, Counterpoise decision, human review, execution, wallet issue, grant and revocation event. Each event links to its predecessor’s hash.

Describe the result accurately: this is a working local policy-to-evidence chain. It does not include authenticated people, remote integrations, a public trust service, independently anchored immutable storage or complete privacy/security detection.
