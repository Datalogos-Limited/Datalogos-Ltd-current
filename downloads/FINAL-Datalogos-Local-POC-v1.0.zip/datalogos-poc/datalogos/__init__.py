"""Datalogos local proof of concept, version 1.0.0."""
__version__ = "1.0.0"
