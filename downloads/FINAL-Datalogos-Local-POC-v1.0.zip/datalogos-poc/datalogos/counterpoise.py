"""Four explicit engines feed a deterministic policy decision point."""
DEFAULT_POLICY = {"minimum_quality": 95, "allow_external": True, "require_external_consent": True,
                  "allowed_purposes": ["sales-analysis"], "version": 1}


def evaluate(dataset, request, policy):
    v, engines = dataset["assurance"], []

    def engine(name, blocks, reviews=()):
        engines.append({"engine": name, "status": "block" if blocks else "review" if reviews else "pass",
                        "reasons": list(blocks or reviews) or ["Controls passed."]})

    engine("Governance", [reason for condition, reason in [
        (request["purpose"] not in policy["allowed_purposes"], "Requested purpose is outside approved policy."),
        (request["purpose"] != dataset["purpose"], "Requested purpose does not match dataset permissions."),
        (v["quality_score"] < policy["minimum_quality"], "Verity quality is below the policy threshold."),
        (not v["valid_for_aggregation"], "Invalid source rows must be corrected before execution.")
    ] if condition])
    engine("Privacy", [reason for condition, reason in [
        (request["destination"] == "external" and not policy["allow_external"], "External sharing is disabled."),
        (request["destination"] == "external" and policy["require_external_consent"] and v["unconsented_personal_rows"] > 0,
         "External use includes personal records without recorded consent.")
    ] if condition])
    engine("Ethics", [], ["High-impact use requires a distinct human reviewer."] if request["high_impact"] else [])
    engine("Security", [reason for condition, reason in [
        (v["injection_detected"], "Instruction-like content detected: execution is blocked."),
        (dataset["classification"] == "restricted" and request["destination"] == "external", "Restricted data cannot be used for external sharing.")
    ] if condition])
    verdict = "block" if any(e["status"] == "block" for e in engines) else "review" if any(e["status"] == "review" for e in engines) else "allow"
    return {"verdict": verdict, "engines": engines, "policy_version": policy["version"], "engine_version": "counterpoise-1.0"}
