import json
import sqlite3
from contextlib import contextmanager, closing
from .common import canonical, digest, now, Problem

SCHEMA = """
CREATE TABLE IF NOT EXISTS datasets(id TEXT PRIMARY KEY, document TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS runs(id TEXT PRIMARY KEY, document TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS wallets(id TEXT PRIMARY KEY, document TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, document TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS events(seq INTEGER PRIMARY KEY AUTOINCREMENT, document TEXT NOT NULL, previous_hash TEXT NOT NULL, hash TEXT NOT NULL);
CREATE TRIGGER IF NOT EXISTS events_no_update BEFORE UPDATE ON events BEGIN SELECT RAISE(ABORT, 'Audit events cannot be updated'); END;
CREATE TRIGGER IF NOT EXISTS events_no_delete BEFORE DELETE ON events BEGIN SELECT RAISE(ABORT, 'Audit events cannot be deleted'); END;
"""


class Store:
    def __init__(self, path):
        self.path = str(path)
        with closing(self.connect()) as db:
            db.executescript(SCHEMA)

    def connect(self):
        db = sqlite3.connect(self.path, timeout=20)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA journal_mode=WAL")
        return db

    @contextmanager
    def transaction(self):
        db = self.connect()
        try:
            db.execute("BEGIN IMMEDIATE")
            yield db
            db.commit()
        except Exception:
            db.rollback()
            raise
        finally:
            db.close()

    @staticmethod
    def get(db, table, identifier):
        if table not in {"datasets", "runs", "wallets", "settings"}:
            raise ValueError("Unknown table")
        column = "key" if table == "settings" else "id"
        row = db.execute(f"SELECT document FROM {table} WHERE {column}=?", (identifier,)).fetchone()
        if row is None:
            raise Problem("Record not found.", 404)
        return json.loads(row["document"])

    @staticmethod
    def put(db, table, identifier, value):
        if table not in {"datasets", "runs", "wallets", "settings"}:
            raise ValueError("Unknown table")
        column = "key" if table == "settings" else "id"
        db.execute(f"INSERT INTO {table}({column},document) VALUES(?,?) ON CONFLICT({column}) DO UPDATE SET document=excluded.document", (identifier, canonical(value)))

    @staticmethod
    def event(db, actor, kind, entity, details):
        last = db.execute("SELECT hash FROM events ORDER BY seq DESC LIMIT 1").fetchone()
        previous = last["hash"] if last else "0" * 64
        document = {"at": now(), "actor": actor, "kind": kind, "entity": entity, "details": details}
        hashed = digest({"previous_hash": previous, "event": document})
        db.execute("INSERT INTO events(document,previous_hash,hash) VALUES(?,?,?)", (canonical(document), previous, hashed))

    @staticmethod
    def verify_audit(db):
        previous, count = "0" * 64, 0
        for row in db.execute("SELECT * FROM events ORDER BY seq"):
            count += 1
            if row["previous_hash"] != previous or digest({"previous_hash": previous, "event": json.loads(row["document"])}) != row["hash"]:
                return {"valid": False, "checked": count, "failed_sequence": row["seq"]}
            previous = row["hash"]
        return {"valid": True, "checked": count, "head": previous,
                "scope": "Local hash-chain consistency. An administrator can replace the database; this is not WORM storage or an external trust anchor."}
