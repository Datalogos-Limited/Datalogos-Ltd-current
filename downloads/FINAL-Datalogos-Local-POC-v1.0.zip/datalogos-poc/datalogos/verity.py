"""Deterministic, bounded data checks. Checks are evidence, not source truth."""
import csv
import io
import re
from decimal import Decimal, InvalidOperation
from .common import Problem, digest

REQUIRED = ["record_id", "region", "amount", "consent"]
REGIONS = {"North", "South", "East", "West"}
INJECTION = re.compile(r"ignore\s+(?:all\s+)?(?:previous|prior)\s+instructions|reveal\s+(?:the\s+)?(?:system\s+prompt|secrets)|bypass\s+(?:all\s+)?(?:policy|controls)|<\|(?:system|im_start)\|>", re.I)
EMAIL = re.compile(r"\b[^\s@,]+@[^\s@,]+\.[^\s@,]+\b")


def parse_csv(content):
    if not isinstance(content, str) or len(content.encode("utf-8")) > 1_000_000:
        raise Problem("CSV must be UTF-8 text under 1 MB.")
    try:
        reader = csv.DictReader(io.StringIO(content.lstrip("\ufeff")), strict=True)
        headers = reader.fieldnames
        if not headers or len(headers) > 30 or len(set(headers)) != len(headers):
            raise Problem("CSV needs 1–30 unique column headings.")
        if any(not h or len(h) > 80 for h in headers):
            raise Problem("Column headings must be non-empty and under 80 characters.")
        if not set(REQUIRED).issubset(headers):
            raise Problem("Missing required columns: " + ", ".join(sorted(set(REQUIRED) - set(headers))))
        rows = []
        for row in reader:
            if None in row or any(v is None for v in row.values()):
                raise Problem("Each CSV row must have exactly the same number of columns as the header.")
            if any(len(v) > 4000 for v in row.values()):
                raise Problem("CSV cells must be under 4,000 characters.")
            rows.append({k: v.strip() for k, v in row.items()})
            if len(rows) > 5000:
                raise Problem("The POC accepts up to 5,000 rows.")
        if not rows:
            raise Problem("CSV needs at least one data row.")
        return rows
    except (csv.Error, UnicodeError) as exc:
        raise Problem("CSV could not be parsed.") from exc


def amount(value):
    try:
        number = Decimal(value)
        return number if number.is_finite() and 0 <= number <= Decimal("1000000000") and number.as_tuple().exponent >= -2 else None
    except (InvalidOperation, ValueError):
        return None


def inspect(rows):
    findings, seen, passed, personal, consent_missing = [], set(), 0, False, 0
    for index, row in enumerate(rows, 1):
        checks = [
            ("identifier", bool(row["record_id"]), "record_id is required"),
            ("uniqueness", bool(row["record_id"]) and row["record_id"] not in seen, "record_id must be unique"),
            ("region", row["region"] in REGIONS, "region must be North, South, East or West"),
            ("amount", amount(row["amount"]) is not None, "amount must be 0–1,000,000,000 with at most two decimal places"),
            ("consent", row["consent"].lower() in {"true", "false"}, "consent must be true or false"),
        ]
        seen.add(row["record_id"])
        for rule, ok, message in checks:
            passed += int(ok)
            if not ok:
                findings.append({"row": index, "rule": rule, "severity": "error", "message": message})
        has_personal = any(EMAIL.search(v) for v in row.values()) or any(
            k.lower() in {"email", "name", "phone", "address", "date_of_birth"} and bool(v) for k, v in row.items())
        personal |= has_personal
        if has_personal and row["consent"].lower() != "true":
            consent_missing += 1
        if any(INJECTION.search(v) for v in row.values()):
            findings.append({"row": index, "rule": "prompt_injection", "severity": "critical", "message": "Instruction-like content detected in untrusted data."})
    return {"rule_version": "verity-1.0", "row_count": len(rows), "quality_score": round(100 * passed / (len(rows) * 5), 1),
            "personal_data_detected": personal, "unconsented_personal_rows": consent_missing,
            "injection_detected": any(f["severity"] == "critical" for f in findings),
            "valid_for_aggregation": not any(f["severity"] == "error" for f in findings),
            "dataset_hash": digest(rows), "findings": findings,
            "limitations": "PII and injection checks use explicit heuristics; undetected risks may remain. Source claims are not independently verified."}


def aggregate(rows):
    groups = {}
    for row in rows:
        value = amount(row["amount"])
        if value is None or row["region"] not in REGIONS:
            raise Problem("Dataset cannot be aggregated safely.", 409)
        entry = groups.setdefault(row["region"], {"region": row["region"], "total": Decimal(0), "record_count": 0})
        entry["total"] += value
        entry["record_count"] += 1
    # Money is exported as decimal strings, avoiding floating point rounding.
    return [{**groups[key], "total": f"{groups[key]['total']:.2f}"} for key in sorted(groups)]
