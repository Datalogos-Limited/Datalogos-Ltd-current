import hashlib
import json
import math
from datetime import datetime, timezone


class Problem(Exception):
    def __init__(self, message, status=400):
        super().__init__(message)
        self.status = status


def canonical(value):
    def normalise(item):
        # JavaScript JSON round-trips 100.0 as 100. Treat both identically so
        # browser verification preserves the signed payload's numeric meaning.
        if isinstance(item, float):
            if not math.isfinite(item):
                raise ValueError("Non-finite JSON number")
            return int(item) if item.is_integer() else item
        if isinstance(item, dict):
            return {key: normalise(val) for key, val in item.items()}
        if isinstance(item, (list, tuple)):
            return [normalise(val) for val in item]
        return item
    return json.dumps(normalise(value), sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)


def digest(value):
    return hashlib.sha256(canonical(value).encode("utf-8")).hexdigest()


def now():
    return datetime.now(timezone.utc).isoformat()


def text(value, field, limit=200):
    if not isinstance(value, str) or not value.strip() or len(value) > limit:
        raise Problem(f"{field} must be non-empty text, at most {limit} characters.")
    return value.strip()


def choice(value, field, allowed):
    if value not in allowed:
        raise Problem(f"{field} must be one of: {', '.join(allowed)}.")
    return value
