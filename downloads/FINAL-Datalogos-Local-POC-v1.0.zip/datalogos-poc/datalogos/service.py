import json
import re
import secrets
from datetime import datetime, timezone, timedelta
from .common import Problem, choice, text, digest, now
from .store import Store
from . import verity, counterpoise, datafolio

PERSONAS = {"operator": "Analyst", "reviewer": "Human reviewer", "admin": "Policy steward"}


class Service:
    def __init__(self, data_dir):
        data_dir.mkdir(parents=True, exist_ok=True)
        self.store = Store(data_dir / "poc.sqlite3")
        # Stable per-installation key, saved separately from the database.
        keyfile = data_dir / "issuer.key"
        if not keyfile.exists():
            try:
                with keyfile.open("xb") as stream:
                    stream.write(secrets.token_bytes(32))
                keyfile.chmod(0o600)
            except FileExistsError:
                pass
        self.key = keyfile.read_bytes()
        with self.store.transaction() as db:
            if not db.execute("SELECT 1 FROM settings WHERE key='policy'").fetchone():
                self.store.put(db, "settings", "policy", counterpoise.DEFAULT_POLICY)
                self.store.event(db, "system", "policy.initialised", "policy", counterpoise.DEFAULT_POLICY)

    def require(self, actor, allowed):
        if actor not in allowed:
            raise Problem("Switch to the required demonstration persona to perform this action.", 403)

    def dataset(self, body, actor):
        self.require(actor, {"operator", "admin"})
        rows = verity.parse_csv(body.get("csv"))
        document = {"id": secrets.token_hex(8), "name": text(body.get("name"), "Name"),
                    "source": text(body.get("source"), "Source"), "owner": text(body.get("owner"), "Owner"),
                    "purpose": choice(body.get("purpose"), "Purpose", ["sales-analysis", "recruitment"]),
                    "classification": choice(body.get("classification"), "Classification", ["internal", "restricted"]),
                    "imported_at": now(), "rows": rows, "assurance": verity.inspect(rows)}
        with self.store.transaction() as db:
            self.store.put(db, "datasets", document["id"], document)
            self.store.event(db, actor, "verity.inspected", document["id"], {"hash": document["assurance"]["dataset_hash"], "score": document["assurance"]["quality_score"], "source": document["source"]})
        return {k: v for k, v in document.items() if k != "rows"}

    def evaluate(self, body, actor):
        self.require(actor, {"operator", "admin"})
        if type(body.get("high_impact")) is not bool:
            raise Problem("high_impact must be true or false.")
        request = {"purpose": choice(body.get("purpose"), "Purpose", ["sales-analysis", "recruitment"]),
                   "destination": choice(body.get("destination"), "Destination", ["internal", "external"]),
                   "high_impact": body["high_impact"], "action": "regional-sales-summary"}
        with self.store.transaction() as db:
            dataset = self.store.get(db, "datasets", text(body.get("dataset_id"), "Dataset ID"))
            policy = self.store.get(db, "settings", "policy")
            decision = counterpoise.evaluate(dataset, request, policy)
            run = {"id": secrets.token_hex(8), "dataset_id": dataset["id"], "dataset_hash": dataset["assurance"]["dataset_hash"],
                   "created_at": now(), "actor": actor, "request": request, "decision": decision, "state": decision["verdict"],
                   "approval": None, "output": None, "wallet_id": None}
            self.store.put(db, "runs", run["id"], run)
            self.store.event(db, actor, "counterpoise.decided", run["id"], decision)
        return run

    def approval(self, identifier, body, actor):
        self.require(actor, {"reviewer"})
        decision = choice(body.get("decision"), "Decision", ["approve", "reject"])
        reason = text(body.get("reason"), "Reviewer rationale", 1000)
        with self.store.transaction() as db:
            run = self.store.get(db, "runs", identifier)
            if run["state"] != "review" or run["actor"] == actor:
                raise Problem("Only pending requests can be reviewed by a distinct persona.", 409)
            run["approval"] = {"actor": actor, "decision": decision, "reason": reason, "at": now()}
            run["state"] = "approved" if decision == "approve" else "rejected"
            self.store.put(db, "runs", identifier, run)
            self.store.event(db, actor, "counterpoise.reviewed", identifier, run["approval"])
        return run

    def execute(self, identifier, actor):
        self.require(actor, {"operator", "admin"})
        with self.store.transaction() as db:
            run = self.store.get(db, "runs", identifier)
            if run["state"] not in {"allow", "approved"}:
                raise Problem("Enforcement prevented execution: request is blocked, pending, rejected or already executed.", 409)
            dataset = self.store.get(db, "datasets", run["dataset_id"])
            if digest(dataset["rows"]) != run["dataset_hash"]:
                raise Problem("Source data changed after evaluation. Import and evaluate again.", 409)
            if verity.inspect(dataset["rows"]) != dataset["assurance"]:
                raise Problem("Stored assurance no longer matches the source data. Import and evaluate again.", 409)
            policy = self.store.get(db, "settings", "policy")
            fresh = counterpoise.evaluate(dataset, run["request"], policy)
            if fresh["policy_version"] != run["decision"]["policy_version"] or fresh["verdict"] == "block" or (fresh["verdict"] == "review" and run["state"] != "approved"):
                raise Problem("Policy authority is stale or invalid. Evaluate a new request.", 409)
            if fresh != run["decision"]:
                raise Problem("Assurance or decision evidence changed. Evaluate a new request.", 409)
            if run["state"] == "approved" and (not run["approval"] or run["approval"]["decision"] != "approve"):
                raise Problem("Approval is missing.", 409)
            output = verity.aggregate(dataset["rows"])
            wallet_id = secrets.token_hex(8)
            payload = {"id": wallet_id, "issued_at": now(), "run_id": identifier,
                       "records": output, "provenance": {"dataset_id": dataset["id"], "dataset_name": dataset["name"],
                       "source": dataset["source"], "owner": dataset["owner"], "imported_at": dataset["imported_at"],
                       "dataset_hash": run["dataset_hash"], "transformation": "Sum amount by region; omit all personal fields."},
                       "assurance": dataset["assurance"], "decision": run["decision"], "approval": run["approval"],
                       "permissions": {"purpose": run["request"]["purpose"], "destination": run["request"]["destination"],
                       "classification": dataset["classification"], "scope": "Aggregated regional totals only"}}
            wallet = {"id": wallet_id, "bundle": datafolio.seal(payload, self.key), "revoked_at": None, "grants": []}
            run.update(state="executed", output=output, wallet_id=wallet_id, executed_at=now())
            self.store.put(db, "wallets", wallet_id, wallet)
            self.store.put(db, "runs", identifier, run)
            self.store.event(db, actor, "counterpoise.executed", identifier, {"output_hash": digest(output), "wallet_id": wallet_id})
            self.store.event(db, actor, "datafolio.issued", wallet_id, {"digest": wallet["bundle"]["digest"]})
        return run

    def policy(self, body, actor):
        self.require(actor, {"admin"})
        quality = body.get("minimum_quality")
        if type(quality) is not int or not 0 <= quality <= 100:
            raise Problem("minimum_quality must be an integer from 0 to 100.")
        for field in ["allow_external", "require_external_consent"]:
            if type(body.get(field)) is not bool:
                raise Problem(f"{field} must be true or false.")
        purposes = body.get("allowed_purposes")
        if not isinstance(purposes, list) or not purposes or any(p not in ["sales-analysis", "recruitment"] for p in purposes):
            raise Problem("Choose at least one supported purpose.")
        with self.store.transaction() as db:
            old = self.store.get(db, "settings", "policy")
            policy = {"minimum_quality": quality, "allow_external": body["allow_external"],
                      "require_external_consent": body["require_external_consent"], "allowed_purposes": list(dict.fromkeys(purposes)), "version": old["version"] + 1}
            self.store.put(db, "settings", "policy", policy)
            self.store.event(db, actor, "policy.changed", "policy", {"before": old, "after": policy})
        return policy

    def grant(self, identifier, body, actor):
        self.require(actor, {"operator", "admin"})
        recipient = text(body.get("recipient"), "Recipient")
        if not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", recipient):
            raise Problem("Recipient must be an email address (no message is sent).")
        ttl = body.get("minutes")
        if type(ttl) is not int or not 1 <= ttl <= 60:
            raise Problem("Grant duration must be 1–60 minutes.")
        fields = body.get("fields")
        if not isinstance(fields, list) or not fields or any(f not in ["region", "total", "record_count"] for f in fields):
            raise Problem("Select supported aggregate fields only.")
        with self.store.transaction() as db:
            wallet = self.store.get(db, "wallets", identifier)
            if wallet["revoked_at"]:
                raise Problem("Wallet has been revoked.", 409)
            if wallet["bundle"]["payload"]["permissions"]["destination"] != "external":
                raise Problem("This wallet permits internal use only. Evaluate an external request first.", 403)
            # Apply current policy again before issuing a sharing capability.
            run = self.store.get(db, "runs", wallet["bundle"]["payload"]["run_id"])
            dataset = self.store.get(db, "datasets", run["dataset_id"])
            policy = self.store.get(db, "settings", "policy")
            fresh = counterpoise.evaluate(dataset, run["request"], policy)
            if fresh["policy_version"] != run["decision"]["policy_version"] or fresh["verdict"] == "block":
                raise Problem("Wallet authority is stale. Evaluate and execute a new external request.", 409)
            grant = {"id": secrets.token_hex(8), "recipient": recipient, "fields": list(dict.fromkeys(fields)),
                     "created_at": now(), "expires_at": (datetime.now(timezone.utc) + timedelta(minutes=ttl)).isoformat(), "revoked_at": None}
            wallet["grants"].append(grant)
            self.store.put(db, "wallets", identifier, wallet)
            self.store.event(db, actor, "datafolio.grant.created", identifier, grant)
        return grant

    def export(self, identifier, grant_id=None):
        with self.store.transaction() as db:
            wallet = self.store.get(db, "wallets", identifier)
            if wallet["revoked_at"]:
                raise Problem("Wallet has been revoked.", 403)
            if not grant_id:
                return wallet["bundle"]
            grant = next((g for g in wallet["grants"] if g["id"] == grant_id), None)
            if not grant:
                raise Problem("Grant not found.", 404)
            if grant["revoked_at"] or datetime.fromisoformat(grant["expires_at"]) <= datetime.now(timezone.utc):
                raise Problem("Grant is revoked or expired.", 403)
            run = self.store.get(db, "runs", wallet["bundle"]["payload"]["run_id"])
            dataset = self.store.get(db, "datasets", run["dataset_id"])
            policy = self.store.get(db, "settings", "policy")
            if policy["version"] != run["decision"]["policy_version"] or counterpoise.evaluate(dataset, run["request"], policy)["verdict"] == "block":
                raise Problem("Sharing authority is stale. Re-evaluate the workflow.", 403)
            payload = json.loads(json.dumps(wallet["bundle"]["payload"]))
            payload["records"] = [{k: row[k] for k in grant["fields"]} for row in payload["records"]]
            payload["grant"] = grant
            return datafolio.seal(payload, self.key)

    def revoke(self, identifier, body, actor):
        self.require(actor, {"operator", "admin"})
        grant_id = body.get("grant_id")
        with self.store.transaction() as db:
            wallet = self.store.get(db, "wallets", identifier)
            target = wallet if not grant_id else next((g for g in wallet["grants"] if g["id"] == grant_id), None)
            if target is None:
                raise Problem("Grant not found.", 404)
            if target["revoked_at"]:
                raise Problem("Already revoked.", 409)
            target["revoked_at"] = now()
            self.store.put(db, "wallets", identifier, wallet)
            self.store.event(db, actor, "datafolio.revoked", identifier, {"grant_id": grant_id, "at": target["revoked_at"]})
        return wallet

    def verify(self, bundle):
        result = datafolio.check(bundle, self.key)
        result["permission_active"] = False
        if result["integrity_valid"] and result["issuer_valid"]:
            payload = bundle["payload"]
            with self.store.transaction() as db:
                try:
                    wallet = self.store.get(db, "wallets", payload["id"])
                    active = not wallet["revoked_at"]
                    run = self.store.get(db, "runs", payload["run_id"])
                    policy = self.store.get(db, "settings", "policy")
                    active = active and policy["version"] == run["decision"]["policy_version"]
                    if payload.get("grant"):
                        grant = next((g for g in wallet["grants"] if g["id"] == payload["grant"]["id"]), None)
                        active = active and bool(grant) and not grant["revoked_at"] and datetime.fromisoformat(grant["expires_at"]) > datetime.now(timezone.utc)
                    result["permission_active"] = bool(active)
                except (Problem, KeyError, ValueError):
                    pass
        return result

    def state(self):
        with self.store.transaction() as db:
            def all_docs(table):
                return [json.loads(r["document"]) for r in db.execute(f"SELECT document FROM {table} ORDER BY rowid DESC")]
            datasets = [{k: v for k, v in d.items() if k != "rows"} for d in all_docs("datasets")]
            events = [{"seq": row["seq"], **json.loads(row["document"]), "hash": row["hash"], "previous_hash": row["previous_hash"]} for row in db.execute("SELECT * FROM events ORDER BY seq DESC LIMIT 200")]
            return {"datasets": datasets, "runs": all_docs("runs"), "wallets": all_docs("wallets"),
                    "policy": self.store.get(db, "settings", "policy"), "events": events, "audit": self.store.verify_audit(db)}
