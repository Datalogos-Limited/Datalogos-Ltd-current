import hashlib
import hmac
from .common import canonical, digest


def seal(payload, key):
    body = {"format": "datalogos-datafolio-1.0", "payload": payload, "digest": digest(payload)}
    return {**body, "signature": hmac.new(key, canonical(body).encode(), hashlib.sha256).hexdigest(),
            "proof": {"digest": "SHA-256", "signature": "HMAC-SHA-256", "trust": "Originating local installation only"}}


def check(bundle, key=None):
    if not isinstance(bundle, dict) or bundle.get("format") != "datalogos-datafolio-1.0" or not isinstance(bundle.get("payload"), dict):
        return {"integrity_valid": False, "issuer_valid": False, "message": "Unsupported bundle format."}
    expected = digest(bundle["payload"])
    integrity = isinstance(bundle.get("digest"), str) and hmac.compare_digest(expected, bundle["digest"])
    issuer = None
    if key is not None:
        body = {"format": bundle["format"], "payload": bundle["payload"], "digest": bundle.get("digest")}
        signature = hmac.new(key, canonical(body).encode(), hashlib.sha256).hexdigest()
        issuer = isinstance(bundle.get("signature"), str) and hmac.compare_digest(signature, bundle["signature"])
    return {"integrity_valid": integrity, "issuer_valid": issuer,
            "message": "Evidence is consistent with this local issuer." if integrity and issuer else "Digest is consistent; issuer not checked." if integrity and issuer is None else "Evidence has changed or issuer does not match."}
