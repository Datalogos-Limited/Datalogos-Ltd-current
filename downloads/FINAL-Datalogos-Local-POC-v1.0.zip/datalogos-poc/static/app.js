'use strict';
const $ = id => document.getElementById(id);
const escapeHTML = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const badge = value => `<span class="badge ${escapeHTML(value)}">${escapeHTML(value.toUpperCase())}</span>`;
const date = value => value ? new Date(value).toLocaleString('en-GB') : '—';
let state, session, selectedDataset, currentRun, selectedScenario, busy = false;
const scenarios = [
  {id:'clean', title:'Clean sales', subtitle:'Allow · internal reporting', file:'clean', destination:'internal'},
  {id:'quality', title:'Poor quality', subtitle:'Block · invalid source rows', file:'poor-quality', destination:'internal'},
  {id:'privacy', title:'Missing consent', subtitle:'Block · external personal data use', file:'missing-consent', destination:'external'},
  {id:'injection', title:'Suspicious instructions', subtitle:'Block · security pattern detected', file:'injection', destination:'internal'},
  {id:'review', title:'Human review', subtitle:'Review · consequential use', file:'clean', destination:'internal', highImpact:true},
  {id:'external', title:'External sharing', subtitle:'Allow · scoped wallet grant', file:'clean', destination:'external'},
  {id:'restricted', title:'Restricted data', subtitle:'Block · external destination', file:'restricted', destination:'external', classification:'restricted'}
];

function notice(message, error=false) { $('notice').hidden = false; $('notice').classList.toggle('error', error); $('notice').textContent = message; }
async function api(path, body) {
  const options = body === undefined ? {} : {method:'POST',headers:{'Content-Type':'application/json','X-CSRF-Token':session.csrf},body:JSON.stringify(body)};
  const response = await fetch(path, options);
  const value = await response.json();
  if (!response.ok) throw new Error(value.error || `Request failed (${response.status})`);
  return value;
}
async function task(action) {
  if (busy) return;
  busy = true;
  document.body.setAttribute('aria-busy','true');
  try { await action(); } catch (error) { notice(error.message, true); }
  finally { busy = false; document.body.removeAttribute('aria-busy'); }
}
function tab(name) {
  document.querySelectorAll('.page').forEach(page => page.hidden = page.id !== name);
  document.querySelectorAll('[data-tab]').forEach(button => button.classList.toggle('active',button.dataset.tab === name));
  $('page-label').textContent = document.querySelector(`[data-tab="${name}"] span`).textContent.toUpperCase();
}
function jsonDetails(label, value) { return `<details><summary>${escapeHTML(label)}</summary><pre>${escapeHTML(JSON.stringify(value,null,2))}</pre></details>`; }
function table(records) {
  if (!records || !records.length) return '';
  const fields = Object.keys(records[0]);
  return `<div class="table-scroll"><table><thead><tr>${fields.map(f=>`<th>${escapeHTML(f.replaceAll('_',' '))}</th>`).join('')}</tr></thead><tbody>${records.map(row=>`<tr>${fields.map(f=>`<td>${escapeHTML(row[f])}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
}
function runView(run, full=true) {
  const dataset = state.datasets.find(d=>d.id===run.dataset_id);
  let controls = '';
  if (['allow','approved'].includes(run.state)) controls = `<button data-execute="${run.id}">Execute permitted action</button>`;
  if (run.state==='review') controls = '<button class="secondary" data-goto="counterpoise">Open human review queue</button>';
  if (run.state==='executed') controls = `<button class="secondary" data-goto="datafolio">Open Datafolio wallet</button>`;
  return `<div class="record"><div class="record-heading"><h3>${escapeHTML(dataset?.name || run.dataset_id)}</h3>${badge(run.state)}</div><p class="mini">${date(run.created_at)} · ${escapeHTML(run.request.purpose)} · ${escapeHTML(run.request.destination)} · Policy v${run.decision.policy_version}</p>${full?`<div class="engine-grid">${run.decision.engines.map(engine=>`<div class="engine"><h3>${engine.engine}</h3>${badge(engine.status)}<p>${engine.reasons.map(escapeHTML).join('<br>')}</p></div>`).join('')}</div>`:''}${run.approval?`<p><strong>Human ${escapeHTML(run.approval.decision)}:</strong> ${escapeHTML(run.approval.reason)}</p>`:''}${run.output?table(run.output):''}<div class="actions">${controls}<span class="mini">Request ${run.id}</span></div></div>`;
}
function render() {
  $('metrics').innerHTML = [
    [state.datasets.length,'Datasets inspected'],[state.runs.filter(r=>r.state==='executed').length,'Actions executed'],
    [state.runs.filter(r=>r.state==='block').length,'Requests blocked'],[state.wallets.length,'Evidence wallets']
  ].map(([value,label])=>`<div class="metric"><strong>${value}</strong><span>${label}</span></div>`).join('');
  $('scenarios').innerHTML = scenarios.map(s=>`<button class="scenario ${selectedScenario===s.id?'selected':''}" data-scenario="${s.id}"><strong>${s.title}</strong><small>${s.subtitle}</small></button>`).join('');
  selectedDataset ||= state.datasets[0]?.id;
  $('dataset-select').innerHTML = state.datasets.length ? state.datasets.map(d=>`<option value="${d.id}" ${selectedDataset===d.id?'selected':''}>${escapeHTML(d.name)} · ${d.assurance.quality_score}%</option>`).join('') : '<option value="">Load a scenario first</option>';
  $('evaluate').disabled = !selectedDataset || !['operator','admin'].includes(session.persona);
  const run = state.runs.find(r=>r.id===currentRun);
  $('current-run').innerHTML = run ? runView(run) : '<div class="empty">Load a scenario and evaluate it to see the four engines at work.</div>';
  $('datasets-list').innerHTML = state.datasets.length ? state.datasets.map(d=>`<article class="panel"><div class="panel-title"><h2>${escapeHTML(d.name)}</h2><span class="tag">QUALITY ${d.assurance.quality_score}%</span></div><div class="metadata"><div><span>DECLARED SOURCE</span>${escapeHTML(d.source)}</div><div><span>ACCOUNTABLE OWNER</span>${escapeHTML(d.owner)}</div><div><span>CLASSIFICATION</span>${escapeHTML(d.classification)}</div><div><span>PURPOSE</span>${escapeHTML(d.purpose)}</div><div><span>RECORDS</span>${d.assurance.row_count}</div><div><span>PERSONAL DATA SIGNAL</span>${d.assurance.personal_data_detected?'Detected':'Not detected'}</div></div><p class="mini">Imported ${date(d.imported_at)} · Verity rules ${d.assurance.rule_version}</p><p class="mini">Dataset SHA-256 <code>${d.assurance.dataset_hash}</code></p>${d.assurance.findings.length?table(d.assurance.findings):'<div class="result-box">All five row-quality checks passed. No configured instruction pattern detected.</div>'}<p class="hint">${escapeHTML(d.assurance.limitations)}</p></article>`).join('') : '<div class="empty">Load a demonstration or import a CSV from Governed workflow.</div>';
  const reviews = state.runs.filter(r=>r.state==='review');
  $('reviews').innerHTML = reviews.length ? reviews.map(r=>`<div class="record"><h3>${escapeHTML(state.datasets.find(d=>d.id===r.dataset_id)?.name)}</h3><p class="mini">Request ${r.id} · ${date(r.created_at)}</p><label>Reviewer rationale <textarea id="reason-${r.id}" rows="2" maxlength="1000" placeholder="Explain the permitted use and oversight"></textarea></label><div class="actions"><button data-approve="${r.id}" ${session.persona!=='reviewer'?'disabled':''}>Approve</button><button class="danger" data-reject="${r.id}" ${session.persona!=='reviewer'?'disabled':''}>Reject</button></div></div>`).join('') : '<div class="empty">No requests waiting for review.</div>';
  const p = state.policy;
  $('policy-version').textContent = `VERSION ${p.version}`;
  $('minimum-quality').value = p.minimum_quality;
  $('allow-external').checked = p.allow_external;
  $('require-consent').checked = p.require_external_consent;
  $('allow-sales').checked = p.allowed_purposes.includes('sales-analysis');
  $('allow-recruitment').checked = p.allowed_purposes.includes('recruitment');
  $('policy-form').querySelector('button').disabled = session.persona !== 'admin';
  $('runs-list').innerHTML = state.runs.length ? state.runs.map(r=>runView(r,false)).join('') : '<div class="empty">No requests evaluated yet.</div>';
  $('wallets-list').innerHTML = state.wallets.length ? state.wallets.map(w=>walletView(w)).join('') : '<div class="empty">Execute a permitted action to create your first Datafolio wallet.</div>';
  $('audit-result').innerHTML = `<div class="status-line">${badge(state.audit.valid?'pass':'block')}<span>${state.audit.checked} events checked</span></div><p class="mini">Head <code>${escapeHTML(state.audit.head || state.audit.failed_sequence)}</code></p>`;
  $('events-list').innerHTML = `<div class="table-scroll"><table><thead><tr><th>Event</th><th>Time / actor</th><th>Entity</th><th>Evidence</th></tr></thead><tbody>${state.events.map(e=>`<tr><td>${e.seq} · ${escapeHTML(e.kind)}</td><td>${date(e.at)}<br>${escapeHTML(e.actor)}</td><td><code>${escapeHTML(e.entity)}</code></td><td>${jsonDetails('Inspect event and hashes',e)}</td></tr>`).join('')}</tbody></table></div>`;
}
function walletView(w) {
  const payload=w.bundle.payload, external=payload.permissions.destination==='external', revoked=!!w.revoked_at;
  return `<article class="panel"><div class="panel-title wallet-header"><div><h2>${escapeHTML(payload.provenance.dataset_name)}</h2><p class="mini">Wallet ${w.id} · ${date(payload.issued_at)}</p></div>${badge(revoked?'revoked':'executed')}</div><p>Permission: ${escapeHTML(payload.permissions.purpose)} · ${escapeHTML(payload.permissions.destination)} · ${escapeHTML(payload.permissions.scope)}</p>${table(payload.records)}<div class="actions"><button data-export="${w.id}" ${revoked?'disabled':''}>Export evidence JSON</button><button class="secondary" data-wallet-verify="${w.id}">Verify wallet</button><button class="danger" data-wallet-revoke="${w.id}" ${revoked?'disabled':''}>Revoke wallet</button></div>${jsonDetails('Inspect provenance, checks and proof',w.bundle)}${external&&!revoked?`<details><summary>Create a scoped sharing grant</summary><p>No email is sent. Recipient is a declared label for this local grant, not authenticated identity.</p><div class="inline-form"><label>Recipient <input id="recipient-${w.id}" type="email" value="investor@example.test"></label><label>Expiry (minutes) <input id="ttl-${w.id}" type="number" min="1" max="60" value="15"></label></div><div class="wallet-fields">${['region','total','record_count'].map(f=>`<label class="check"><input type="checkbox" data-field-wallet="${w.id}" value="${f}" checked>${f.replaceAll('_',' ')}</label>`).join('')}</div><button data-grant="${w.id}">Create time-limited grant</button></details>`:''}${w.grants.map(g=>`<div class="wallet-grant"><div class="record-heading"><strong>${escapeHTML(g.recipient)}</strong>${badge(g.revoked_at||revoked?'revoked':new Date(g.expires_at)<=new Date()?'block':'allow')}</div><p class="mini">Selected fields: ${escapeHTML(g.fields.join(', '))} · Expires ${date(g.expires_at)}</p><div class="actions"><button class="small secondary" data-grant-export="${w.id}" data-grant-id="${g.id}" ${g.revoked_at||revoked?'disabled':''}>Export scoped bundle</button><button class="small danger" data-grant-revoke="${w.id}" data-grant-id="${g.id}" ${g.revoked_at||revoked?'disabled':''}>Revoke grant</button></div></div>`).join('')}<p class="hint">Revocation prevents future access through this installation. It cannot recall a previously exported copy. Offline digest checks cannot confirm current permission.</p></article>`;
}
async function refresh() { state = await api('/api/state'); render(); }
async function exportBundle(id, grantId) {
  const bundle = await api(`/api/wallets/${id}/export${grantId?'?grant_id='+grantId:''}`);
  const content = JSON.stringify(bundle,null,2);
  $('bundle-json').value = content;
  const url = URL.createObjectURL(new Blob([content],{type:'application/json'}));
  const link = document.createElement('a'); link.href=url; link.download=`Datafolio-${id}${grantId?'-scoped':''}.json`; link.click(); URL.revokeObjectURL(url);
  notice('Evidence exported. A copy is ready in the verification field below.');
}
function verification(result) {
  $('verification').innerHTML = `<div class="result-box"><p><strong>Record integrity:</strong> ${result.integrity_valid?'Valid':'Failed'} · <strong>Local issuer:</strong> ${result.issuer_valid?'Valid':'Failed'} · <strong>Live permission:</strong> ${result.permission_active?'Active':'Inactive'}</p><p>${escapeHTML(result.message)}</p></div>`;
}
document.addEventListener('click', event => {
  const b=event.target.closest('button'); if(!b || b.disabled) return;
  if(b.dataset.tab) return tab(b.dataset.tab);
  if(b.dataset.goto) return tab(b.dataset.goto);
  if(b.closest('#policy-form')) return; // The form's submit handler owns this action.
  task(async()=>{
    if(b.dataset.scenario){
      const s=scenarios.find(s=>s.id===b.dataset.scenario);
      const response=await fetch(`/samples/${s.file}.csv`); if(!response.ok) throw new Error('Sample could not be loaded.');
      const d=await api('/api/datasets',{csv:await response.text(),name:s.title,source:`Bundled synthetic example: ${s.file}.csv`,owner:'Datalogos demonstration team',purpose:'sales-analysis',classification:s.classification || 'internal'});
      selectedDataset=d.id; selectedScenario=s.id; currentRun=null;
      $('destination').value=s.destination; $('purpose').value='sales-analysis'; $('high-impact').checked=!!s.highImpact;
      await refresh(); notice(`Verity inspected ${s.title}. Choose Evaluate to obtain a policy decision.`);
    }else if(b.id==='evaluate'){
      const run=await api('/api/evaluate',{dataset_id:$('dataset-select').value,purpose:$('purpose').value,destination:$('destination').value,high_impact:$('high-impact').checked}); currentRun=run.id;
      await refresh(); notice(`Counterpoise decision: ${run.state.toUpperCase()}.`);
    }else if(b.dataset.execute){
      const run=await api(`/api/runs/${b.dataset.execute}/execute`,{}); currentRun=run.id; await refresh(); notice('Permitted action executed. Datafolio wallet created with aggregate records and evidence.');
    }else if(b.dataset.approve||b.dataset.reject){
      const id=b.dataset.approve||b.dataset.reject;
      await api(`/api/runs/${id}/approve`,{decision:b.dataset.approve?'approve':'reject',reason:$(`reason-${id}`).value}); currentRun=id; await refresh(); notice('Review recorded. Switch to Analyst to execute an approved action.');
    }else if(b.id==='import-csv'){
      const file=$('csv-file').files[0]; if(!file) throw new Error('Choose a CSV file first.'); if(file.size>1000000) throw new Error('CSV must be under 1 MB.');
      const d=await api('/api/datasets',{csv:await file.text(),name:$('dataset-name').value,source:$('dataset-source').value,owner:$('dataset-owner').value,purpose:$('dataset-purpose').value,classification:$('classification').value}); selectedDataset=d.id; selectedScenario=null; currentRun=null; await refresh(); notice('CSV imported and inspected by Verity.');
    }else if(b.dataset.export){await exportBundle(b.dataset.export);
    }else if(b.dataset.grantExport){await exportBundle(b.dataset.grantExport,b.dataset.grantId);
    }else if(b.dataset.walletVerify){
      const w=state.wallets.find(w=>w.id===b.dataset.walletVerify); $('bundle-json').value=JSON.stringify(w.bundle,null,2); verification(await api('/api/verify',{bundle:w.bundle})); notice('Wallet proof and current permission checked.');
    }else if(b.dataset.walletRevoke||b.dataset.grantRevoke){
      const id=b.dataset.walletRevoke||b.dataset.grantRevoke;
      await api(`/api/wallets/${id}/revoke`,b.dataset.grantId?{grant_id:b.dataset.grantId}:{}); await refresh(); notice('Revocation recorded. Future access is prevented; previously exported copies remain.');
    }else if(b.dataset.grant){
      const id=b.dataset.grant;
      const fields=[...document.querySelectorAll(`[data-field-wallet="${id}"]:checked`)].map(el=>el.value);
      await api(`/api/wallets/${id}/grant`,{recipient:$(`recipient-${id}`).value,minutes:Number($(`ttl-${id}`).value),fields}); await refresh(); notice('Scoped grant created. Export selected records from the grant below.');
    }else if(b.id==='verify-bundle'){
      let bundle; try{bundle=JSON.parse($('bundle-json').value);}catch{throw new Error('Paste or upload valid bundle JSON.');}
      verification(await api('/api/verify',{bundle})); notice('Integrity, local issuer and live permission checked.');
    }else if(b.id==='refresh-audit'){await refresh(); notice('Audit chain rechecked.');}
  });
});
$('persona').addEventListener('change',()=>task(async()=>{const persona=$('persona').value;try{await api('/api/persona',{persona});session.persona=persona;await refresh();notice('Demonstration persona changed. These roles do not authenticate a real user.');}catch(e){$('persona').value=session.persona;throw e;}}));
$('dataset-select').addEventListener('change',()=>{selectedDataset=$('dataset-select').value;});
$('bundle-file').addEventListener('change',()=>task(async()=>{const f=$('bundle-file').files[0];if(f){if(f.size>1500000)throw new Error('Evidence file is too large.');$('bundle-json').value=await f.text();}}));
$('policy-form').addEventListener('submit',event=>{event.preventDefault();task(async()=>{const allowed=[];if($('allow-sales').checked)allowed.push('sales-analysis');if($('allow-recruitment').checked)allowed.push('recruitment');await api('/api/policy',{minimum_quality:Number($('minimum-quality').value),allow_external:$('allow-external').checked,require_external_consent:$('require-consent').checked,allowed_purposes:allowed});await refresh();notice('New policy version saved. Evaluate new requests before execution or sharing.');});});
task(async()=>{session=await api('/api/session');$('persona').value=session.persona;await refresh();}).catch(error=>notice(error.message,true));
