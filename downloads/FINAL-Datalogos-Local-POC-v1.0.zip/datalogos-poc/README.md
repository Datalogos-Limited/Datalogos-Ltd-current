# Datalogos local proof of concept

**Counterpoise · Verity · Datafolio | Version 1.0.0 | 3 October 2026**

A working, offline demonstration of a governed data workflow. It inspects sales data, evaluates four policy engines, enforces the resulting decision, executes an aggregate report, and carries the report with its provenance and permission evidence in a Datafolio wallet.

## Start in two minutes

Requires **Python 3.10 or later** and a modern browser. There are **no pip dependencies, cloud credentials, API keys, external fonts, CDNs or subscription requirements**. Python must already be installed for an entirely offline start.

1. Extract the ZIP. Keep the `datalogos-poc` folder and its contents together.
2. Open Terminal or Command Prompt in that folder.
3. Run:

```bash
# macOS / Linux
python3 app.py
```

```bat
:: Windows (Python launcher)
py -3 app.py
```

4. Open **http://127.0.0.1:8765** in your browser.
5. Choose **Clean sales → Evaluate with Counterpoise → Execute permitted action**.
6. Open **Datafolio wallets** to inspect and export the resulting evidence JSON.

On Windows you can also double-click `Start-Windows.bat`. On macOS, `Start-Mac.command` is a convenience launcher; if macOS prevents execution, use the Terminal command above. On Linux, use `bash start.sh`. These launchers were packaged; automated testing was performed on Linux, not Windows or macOS.

If the port is occupied:

```bash
python3 app.py --port 8766
```

Open the corresponding port in your browser. The app binds to `127.0.0.1` only. The browser interface is served by Python; do not double-click `static/index.html`.

## What works

| Product | Working capability | Observable result |
|---|---|---|
| Verity | CSV import, five row-quality rules, duplicates, consent signals, declared provenance, personal-data heuristics, configured injection patterns, SHA-256 input fingerprint | Dataset score, row-level findings and input hash |
| Counterpoise | Governance, Privacy, Ethics and Security engines; deterministic decision authority; versioned policy; human review; execution enforcement | Allow, review or block; blocked requests cannot execute; stale policy decisions require re-evaluation |
| Datafolio | Aggregated records plus checks, provenance, decision and approval; SHA-256 and local HMAC signature; selected-field sharing; expiry; revocation; verification | Portable JSON evidence; expired/revoked grants cannot export; changed records fail issuer verification |
| Shared services | Local HTTP API, persistent SQLite, browser UI, CSRF protection, loopback binding, hash-chained events | Records survive restart; connected evidence can be inspected |

The executed action is **a deterministic regional sales report**, not a remote AI service. Notes never become executable instructions. This makes the policy-to-action chain directly testable offline. No outbound email or network call is implemented.

## Seven built-in scenarios

| Scenario | Expected decision | Why |
|---|---|---|
| Clean sales | Allow | Valid rows, permitted purpose and internal use |
| Poor quality | Block | Duplicate/missing identifiers, invalid regions and amounts |
| Missing consent | Block for external use | A personal-data record has `consent=false` |
| Suspicious instructions | Block | A configured prompt-injection pattern is present |
| Human review | Review | Caller declares a consequential use; distinct reviewer persona needed |
| External sharing | Allow | Valid consented data, external policy enabled; creates a wallet eligible for scoped grants |
| Restricted data | Block for external use | Restricted classification prevents external sharing |

## Your own data

Use **Import your own CSV** on the workflow screen. Upload UTF-8 CSV with these headings:

```csv
record_id,region,amount,consent,email,notes
R001,North,125.50,true,person@example.test,Synthetic example
```

- Required: `record_id`, `region`, `amount`, `consent`.
- Regions: `North`, `South`, `East`, `West` (case-sensitive).
- Amount: 0–1,000,000,000, with at most two decimal places. Monetary output uses decimal strings.
- Consent: `true` or `false` (case-insensitive). This is a declared flag, not verified legal consent.
- Optional: `email`, `notes` and other text columns. Names such as `name`, `phone`, `address` and `date_of_birth` are treated as potential personal fields.
- Limits: 1 MB CSV, 5,000 rows, 30 unique headings, 4,000 characters per cell. Malformed structure is rejected before storage; poor-quality rows are stored for inspection but cannot execute.
- Final output contains only region, total and record count; source personal fields are excluded.

## Demo roles and policy

The top-right selector provides **Analyst**, **Human reviewer**, and **Policy steward**. These are deliberately **selectable demo personas**, not real authentication. The backend enforces permitted transitions for these personas. Anyone with local access can change persona.

- Analyst: import, evaluate, execute permitted actions, grant and revoke.
- Human reviewer: approve or reject pending review requests with a rationale. Cannot approve a hard block or execute.
- Policy steward: amend policy, import and execute. Every policy save advances the version.
- All personas can inspect the local evidence.

Policy changes invalidate previous execution/sharing authority. Lowering a quality threshold does not permit structurally invalid rows. Enabling a purpose in policy also requires matching dataset-purpose permission.

## Local records and backups

On first start the app creates:

```text
runtime/
  poc.sqlite3     local data, decisions, wallets and audit events
  issuer.key      private key for this installation's evidence signatures
```

Stop the app with **Ctrl+C** before backing up the whole `runtime` folder. Retain the database and key together. Do not share the issuer key. To start a clean demo, stop the app and move the runtime folder aside; the next start creates a new installation with a new key. Old bundles will then fail issuer verification in the new installation. No runtime data or signing key is included in this distribution.

Custom storage directory:

```bash
python3 app.py --data-dir /path/to/local/poc-data
```

## Verify and test

```bash
# Run all built-in tests (no third-party packages)
python3 -m unittest discover -s tests -v

# Offline digest check of an exported wallet (no issuer or live permission check)
python3 verify_bundle.py /path/to/Datafolio-evidence.json

# Optional local issuer check on the originating machine
python3 verify_bundle.py /path/to/Datafolio-evidence.json --issuer-key runtime/issuer.key
```

All 28 built-in Python tests passed on Linux with Python 3.12. Front-end event tests passed against the local API using a DOM stub. Full visual browser validation could not be completed because the execution environment's browser download failed. Details and the optional Node test are in `docs/VALIDATION.md`.

Use the UI verification panel for live permission status. The standalone verifier cannot determine current revocation or policy status offline. An unkeyed digest can be recomputed by an attacker; only the local HMAC check authenticates consistency with the originating installation.

## Scope and next steps

This POC demonstrates executable product concepts; it is **not production-ready software or a claim that existing repositories are complete**. The implementation was created specifically for this local demonstration.

- Provenance, classification, ownership, purpose and consent are declared inputs.
- The PII and instruction-pattern checks are limited heuristics, not complete DLP or AI-security detection.
- High-impact use is a caller-supplied flag, not automated legal risk classification.
- SHA-256 fingerprints establish consistency, not source truth. HMAC evidence is local, not publicly verifiable digital certification.
- SQLite triggers prevent ordinary audit update/delete through this schema. A machine administrator can remove triggers, replace the database, steal the key or rewrite an entire chain. There is no independent timestamp, WORM store or external checkpoint.
- Grant recipients are metadata labels. This single-user POC does not authenticate recipients or provide remote delivery.
- Revocation prevents future access through this app. It cannot recall an exported copy or enforce how another program uses it.
- Data is stored in plaintext on the local disk; it is not encrypted at rest.
- The standard-library HTTP server is intended for this loopback POC. Do not expose it to a LAN or the internet.

Production development would add authenticated identities and tenants, centrally managed policy approval, external data/model connectors, robust privacy/security controls, signed public-key authority and verification, independent audit anchoring, secure key management, retention controls and operational testing. See `docs/ARCHITECTURE.md`, `docs/API.md`, `docs/DEMO-WALKTHROUGH.md` and `docs/VALIDATION.md`.

## Visual assets and ownership

The interface uses the Datalogos palette: Midnight `#101D32`, Warm Ivory `#F7F4EC`, Teal `#1E9B98`, Proof Cyan `#75D5D0`, Bronze `#B68B55` and supporting colours from the September 2026 playbook. It requests installed Helvetica Neue with local sans-serif fallbacks. Proprietary font files are not redistributed. The header uses a plain-text brand name; the favicon is a neutral initial, not a recreated approved logo master.

Copyright © 2026 Datalogos Limited. All rights reserved. See `NOTICE.txt`.
